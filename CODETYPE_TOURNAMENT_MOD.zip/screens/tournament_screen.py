"""CCS Days tournament mode for CodeType.

Each participant enters their details and completes one official attempt.
Organizers manually calculate team totals from individual results.
"""

from __future__ import annotations

import pygame

from game.audio_manager import SFX_MENU_MOVE, SFX_MENU_SELECT
from game.constants import (
    HAIRLINE_DIM,
    NEON_CYAN,
    NEON_GREEN,
    NEON_ORANGE,
    NEON_PINK,
    NEON_RED,
    NEON_YELLOW,
    PANEL_BG,
    SURFACE_RAISED,
    TARGET_FPS,
    TEXT_BRIGHT,
    TEXT_DIM,
    TOURNAMENT_DIFFICULTY,
    TOURNAMENT_NAME,
    TOURNAMENT_PLAYER_NUMBERS,
    TOURNAMENT_TEAM_NUMBERS,
)
from game.display import toggle_fullscreen
from game.input_map import printable_character
from game.ui import UI, Stage, pulse
from game.tournament import TournamentStore


class CSSTournamentScreen:
    """CCS Days tournament hub for participant registration and attempt tracking.

    Manages team setup, individual participant slots, and tournament progression
    without automatic team totals or brackets. Each participant gets one official
    attempt, identified by team number and player number.
    """

    def __init__(self, screen, settings, assets, audio, leaderboard, difficulty=None):
        self._screen = screen
        self._settings = settings
        self._assets = assets
        self._audio = audio
        self._leaderboard = leaderboard
        self._difficulty = difficulty
        self._tournament = getattr(leaderboard, "tournament", None)
        self._team_index = 0
        self._slot_index = 0
        self._tick = 0.0
        self._rebuild(screen)

    def _rebuild(self, screen: pygame.Surface) -> None:
        width, height = screen.get_size()
        self._ui = UI(self._assets, width, height)
        self._stage = Stage(self._ui, star_count=140, horizon_fraction=0.5, scroll=20.0)

    def set_surface(self, screen: pygame.Surface) -> None:
        self._screen = screen
        self._rebuild(screen)

    def _toggle_fullscreen(self) -> None:
        self.set_surface(toggle_fullscreen(self._settings))

    def run(self, clock: pygame.time.Clock):
        while True:
            dt = clock.tick(TARGET_FPS) / 1000.0
            self._tick += dt
            self._stage.update(dt)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return None
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11:
                        self._toggle_fullscreen()
                        continue
                    result = self._handle_key(event)
                    if result is not None:
                        return result
            self._draw()
            pygame.display.flip()

    def _handle_key(self, event: pygame.event.Event):
        key = event.key
        if key == pygame.K_ESCAPE:
            return self._to_menu()
        if key == pygame.K_TAB or key in (pygame.K_UP, pygame.K_DOWN):
            self._audio.play(SFX_MENU_MOVE)
            if key in (pygame.K_UP, pygame.K_TAB):
                self._move_selection(direction=-1)
            else:
                self._move_selection(direction=1)
            return None
        if key == pygame.K_RETURN or key == getattr(pygame, "K_KP_ENTER", -1):
            return self._start_participant_selection()
        if key == pygame.K_n:
            from screens.main_menu import MainMenuScreen
            return MainMenuScreen(
                self._screen, self._settings, self._assets,
                self._audio, self._leaderboard,
            )
        if key == pygame.K_l:
            from screens.leaderboard_screen import LeaderboardScreen
            self._audio.play(SFX_MENU_SELECT)
            return LeaderboardScreen(
                self._screen, self._settings, self._assets,
                self._audio, self._leaderboard,
            )
        return None

    def _move_selection(self, direction: int) -> None:
        """Navigate between team and player number selection fields."""
        self._slot_index = (self._slot_index + direction) % 2

    def _start_participant_selection(self):
        """Begin CCS Days tournament participant registration."""
        from screens.name_input_screen import NameInputScreen

        self._audio.play(SFX_MENU_SELECT)
        return NameInputScreen(
            self._screen, self._settings, self._assets, self._audio,
            self._leaderboard, "tournament", difficulty=self._difficulty,
            tournament=self._tournament,
        )

    def _to_menu(self):
        from screens.main_menu import MainMenuScreen
        return MainMenuScreen(
            self._screen, self._settings, self._assets,
            self._audio, self._leaderboard,
        )

    def _draw(self) -> None:
        if self._stage.stale(self._screen):
            self._rebuild(self._screen)
        ui = self._ui
        ui.backdrop_fill(self._screen)
        self._stage.draw(self._screen, self._tick)
        self._draw_title()
        self._draw_participant_selection()
        self._draw_footer()

    def _draw_title(self) -> None:
        ui = self._ui
        cx = ui.width // 2
        ui.text(
            self._screen, TOURNAMENT_NAME, 30, TEXT_BRIGHT, cx,
            ui.px(20), bold=True, anchor="midtop", glow=NEON_CYAN,
        )

    def _draw_participant_selection(self) -> None:
        ui = self._ui
        box = ui.centre_panel(700, 450)
        ui.panel(
            self._screen, box, fill=PANEL_BG, alpha=242, border=HAIRLINE_DIM,
            accent=NEON_CYAN, glow=0.34 + 0.2 * pulse(self._tick, 1.8),
        )

        ui.section_label(
            self._screen, "TEAM SELECTION", box.x + ui.px(34), box.y + ui.px(80),
        )
        ui.section_label(
            self._screen, "PLAYER SELECTION", box.x + ui.px(34), box.y + ui.px(172),
        )

        self._draw_team_field(box)
        self._draw_player_field(box)

    def _draw_team_field(self, box: pygame.Rect) -> None:
        ui = self._ui
        focused = self._slot_index == 0
        colour = NEON_CYAN if focused else HAIRLINE_DIM
        left = box.x + ui.px(34)
        width = int((box.width - ui.px(68)) / 2)
        team_field = pygame.Rect(left, box.y + ui.px(112), width, ui.px(52))

        ui.panel(
            self._screen, team_field, fill=SURFACE_RAISED if focused else PANEL_BG,
            alpha=236, border=colour, glow=0.25 if focused else 0.0,
        )
        ui.text(
            self._screen, "TEAM", 14, NEON_CYAN,
            team_field.x + ui.px(14), team_field.y + ui.px(10),
        )
        ui.text(
            self._screen, team_label(self._team_index + 1), 28, TEXT_BRIGHT,
            team_field.centerx, team_field.centery,
            bold=True, anchor="center",
        )

    def _draw_player_field(self, box: pygame.Rect) -> None:
        ui = self._ui
        focused = self._slot_index == 1
        colour = NEON_CYAN if focused else HAIRLINE_DIM
        left = box.x + ui.px(34) + int((box.width - ui.px(68)) / 2)
        width = int((box.width - ui.px(68)) / 2)
        player_field = pygame.Rect(left, box.y + ui.px(212), width, ui.px(52))

        ui.panel(
            self._screen, player_field, fill=SURFACE_RAISED if focused else PANEL_BG,
            alpha=236, border=colour, glow=0.25 if focused else 0.0,
        )
        ui.text(
            self._screen, "PLAYER", 14, NEON_CYAN,
            player_field.x + ui.px(14), player_field.y + ui.px(10),
        )
        ui.text(
            self._screen, player_label(self._player_index + 1), 28, TEXT_BRIGHT,
            player_field.centerx, player_field.centery,
            bold=True, anchor="center",
        )

    def _draw_footer(self) -> None:
        ui = self._ui
        ui.chips(
            self._screen,
            [
                ("TAB", "NAVIGATE"), ("ENTER", "SELECT"), ("ESC", "MENU"),
                ("N", "NEW"),
            ],
            ui.height - ui.px(30),
        )

    @property
    def _team_index(self) -> int:
        return (self._selected_team - 1) % len(TOURNAMENT_TEAM_NUMBERS)

    @property
    def _player_index(self) -> int:
        return (self._selected_player - 1) % len(TOURNAMENT_PLAYER_NUMBERS)

    @property
    def _selected_team(self) -> int:
        return (self._team_index + 5) % len(TOURNAMENT_TEAM_NUMBERS) + 1

    @property
    def _selected_player(self) -> int:
        return (self._player_index + len(TOURNAMENT_PLAYER_NUMBERS)) % len(TOURNAMENT_PLAYER_NUMBERS) + 1


def team_label(number: int) -> str:
    return f"Team {number}"


def player_label(number: int) -> str:
    return f"Player {number}"